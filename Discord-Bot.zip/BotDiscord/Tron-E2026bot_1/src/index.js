import { AttachmentBuilder, Client, EmbedBuilder, Events, GatewayIntentBits, Partials, PermissionFlagsBits } from "discord.js";
import dotenv from "dotenv";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import config from "../config.js";
import { flushLogs, write } from "./log.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
dotenv.config({ path: path.join(root, ".env"), quiet: true });

const recentWelcomes = new Set();
const statePath = path.join(root, "role-message.json");
let roleMessageId = "";

function fail(message) {
  write("ผิดพลาด", message);
  process.exit(1);
}

function person(user, member) {
  const name = member?.displayName || user.globalName || user.username || "ไม่ทราบชื่อ";
  const account = user.username ? `@${user.username}` : "ไม่มีชื่อบัญชี";
  return `${name} (${account}, ${user.id})`;
}

function emojiLabel(emoji) {
  if (emoji?.id) return `${emoji.name ?? "custom"} [${emoji.id}]`;
  return emoji?.name ?? "ไม่ทราบอิโมจิ";
}

function checkSetup() {
  if (Number(process.versions.node.split(".")[0]) < 18) {
    fail("ต้องใช้ Node.js เวอร์ชัน 18 ขึ้นไป");
  }

  const token = process.env.DISCORD_TOKEN?.trim();
  if (!token || token === "ใส่โทเคนบอทตรงนี้") {
    fail("ยังไม่ได้ใส่โทเคน เปิดไฟล์ .env แล้ววางโทเคนหลัง DISCORD_TOKEN=");
  }

  if (!/^\d{17,20}$/.test(config.welcomeChannelId)) {
    fail("ยังไม่ได้ใส่ไอดีห้องต้อนรับ เปิด config.js แล้วใส่ welcomeChannelId");
  }

  if (!/^\d{17,20}$/.test(config.roleChannelId)) {
    fail("ยังไม่ได้ใส่ไอดีห้องเลือกยศ เปิด config.js แล้วใส่ roleChannelId");
  }



  for (const role of config.roles) {
    if (!role.emoji || !role.name) {
      fail("แต่ละยศต้องมี emoji และ name ใน config.js");
    }
    if (!/^\d{17,20}$/.test(role.roleId)) {
      fail(`ยังไม่ได้ใส่ roleId ของยศ "${role.name}" ใน config.js`);
    }
  }

  if (config.roles[0].roleId === config.roles[1].roleId) {
    fail("ยศทั้งสองใช้ roleId เดียวกัน ใส่คนละยศ");
  }

  if (config.roles[0].emoji === config.roles[1].emoji) {
    fail("อิโมจิทั้งสองตัวซ้ำกัน ใส่คนละตัว");
  }
}

function sameEmoji(reactionEmoji, configEmoji) {
  const raw = String(configEmoji).trim();
  const custom = raw.match(/^<a?:(\w+):(\d+)>$/) || raw.match(/^(?:a:)?(\w+):(\d+)$/);
  if (custom) return reactionEmoji.id === custom[2];
  if (/^\d{17,20}$/.test(raw)) return reactionEmoji.id === raw;
  return reactionEmoji.name === raw;
}

function author(guild) {
  const name = config.serverName || guild?.name || "ชุมชน";
  const iconURL = guild?.iconURL?.({ size: 128 });
  return iconURL ? { name, iconURL } : { name };
}

function bannerAttachment() {
  if (config.bannerUrl) return null;
  if (!config.bannerFile) return null;

  const filePath = path.resolve(root, config.bannerFile);
  if (!fs.existsSync(filePath)) return null;

  const name = path.basename(filePath);
  return { file: new AttachmentBuilder(filePath, { name }), name };
}

function roleLines() {
  return config.roles
    .map((role) => `${role.emoji}  **${role.name}**\n${role.description ?? ""}`.trim())
    .join("\n\n");
}

function permissionHint(error, hint) {
  const missing = error?.code === 50013 || /missing permissions/i.test(String(error?.message ?? ""));
  if (!missing) return error?.message ?? String(error);
  return `Missing Permissions: ${hint}`;
}

function missingChannelPermissions(channel, member, needed) {
  const perms = channel.permissionsFor(member);
  return needed.filter(([flag]) => !perms?.has(flag)).map(([, name]) => name);
}

function welcomeEmbed(member) {
  const rules = (config.rules ?? []).map((rule, index) => `${index + 1}. ${rule}`).join("\n");
  const roleChannel = `<#${config.roleChannelId}>`;

  const embed = new EmbedBuilder()
    .setColor(config.embedColor || "#00E5FF")
    .setAuthor(author(member.guild))
    .setTitle("ยินดีต้อนรับเข้าสู่ชุมชน")
    .setDescription(
      [
        `เรียน ${member}`,
        "",
        "ขอต้อนรับท่านเข้าสู่ชุมชน โปรดอ่านกติกาให้ครบถ้วน แล้วดำเนินการรับยศในห้องที่กำหนด เพื่อเข้าใช้งานห้องที่เกี่ยวข้อง",
      ].join("\n"),
    )
    .addFields(
      { name: "กติกาของชุมชน", value: rules || "ยังไม่ได้กำหนดกติกา" },
      {
        name: "การรับยศ",
        value: [`โปรดไปที่ ${roleChannel}`, "เลือกได้ครั้งละหนึ่งยศ โดยกดอิโมจิใต้ประกาศของบอท", "", roleLines()].join("\n"),
      },
    )
    .setThumbnail(member.user.displayAvatarURL({ size: 256 }))
    .setFooter({ text: `${config.serverName || member.guild.name} · โปรดปฏิบัติตามกติกา` })
    .setTimestamp();

  const banner = bannerAttachment();
  if (config.bannerUrl) embed.setImage(config.bannerUrl);
  else if (banner) embed.setImage(`attachment://${banner.name}`);

  return { embed, banner };
}

async function sendWelcome(member) {
  const who = person(member.user, member);
  if (member.user.bot) {
    write("สมาชิก", `${who} เป็นบอท จึงไม่ส่งการ์ดต้อนรับ`);
    return;
  }
  if (member.pending) {
    write("สมาชิก", `${who} ยังไม่ผ่านการคัดกรอง จะส่งการ์ดหลังยอมรับกติกา`);
    return;
  }
  if (recentWelcomes.has(member.id)) {
    write("ต้อนรับ", `${who} ได้รับการ์ดไปแล้วในช่วงไม่กี่วินาทีนี้ จึงไม่ส่งซ้ำ`);
    return;
  }
  recentWelcomes.add(member.id);
  setTimeout(() => recentWelcomes.delete(member.id), 60_000);

  const channel = await member.guild.channels.fetch(config.welcomeChannelId).catch(() => null);
  if (!channel?.isTextBased()) {
    write("ผิดพลาด", `หาห้อง welcome ไม่เจอ จึงส่งการ์ดให้ ${who} ไม่ได้`);
    return;
  }

  const me = member.guild.members.me ?? (await member.guild.members.fetchMe());
  const missing = missingChannelPermissions(channel, me, [
    [PermissionFlagsBits.ViewChannel, "View Channel"],
    [PermissionFlagsBits.SendMessages, "Send Messages"],
    [PermissionFlagsBits.EmbedLinks, "Embed Links"],
  ]);
  if (missing.length) {
    write("ผิดพลาด", `ส่งการ์ดให้ ${who} ไม่ได้ เพราะใน #${channel.name} ขาดสิทธิ์ ${missing.join(", ")}`);
    return;
  }

  const { embed, banner } = welcomeEmbed(member);
  const sent = await channel.send({
    content: `${member} ขอต้อนรับเข้าสู่ **${config.serverName || member.guild.name}** โปรดอ่านประกาศด้านล่าง แล้วไปรับยศที่ <#${config.roleChannelId}>`,
    embeds: [embed],
    files: banner ? [banner.file] : [],
  });

  write("ต้อนรับ", `ส่งการ์ดให้ ${who} ใน #${channel.name} ข้อความ ${sent.id}`);
}

function rolePickEmbed(guild) {
  return new EmbedBuilder()
    .setColor(config.embedColor || "#00E5FF")
    .setAuthor(author(guild))
    .setTitle("ประกาศเลือกยศ")
    .setDescription(
      "โปรดกดอิโมจิใต้ประกาศนี้เพื่อรับยศ\nสมาชิกเลือกได้ครั้งละหนึ่งยศ หากต้องการเปลี่ยนยศ ให้กดอิโมจิอีกรายการ",
    )
    .addFields(
      config.roles.map((role) => ({
        name: `${role.emoji}  ${role.name}`,
        value: role.description || "—",
        inline: true,
      })),
    )
    .setFooter({ text: `${config.serverName || guild?.name || "ชุมชน"} · เลือกได้ครั้งละหนึ่งยศ` });
}

function readRoleMessageId() {
  try {
    const saved = JSON.parse(fs.readFileSync(statePath, "utf8"));
    return typeof saved.messageId === "string" ? saved.messageId : "";
  } catch {
    return "";
  }
}

function saveRoleMessageId(messageId) {
  fs.writeFileSync(statePath, JSON.stringify({ messageId }, null, 2));
  roleMessageId = messageId;
}

async function ensureRolePanel(client) {
  const channel = await client.channels.fetch(config.roleChannelId).catch(() => null);
  if (!channel?.isTextBased()) {
    write("ผิดพลาด", "หาห้องเลือกยศไม่เจอ ตรวจ roleChannelId ใน config.js");
    return;
  }

  const me = channel.guild.members.me ?? (await channel.guild.members.fetchMe());
  const missing = missingChannelPermissions(channel, me, [
    [PermissionFlagsBits.ViewChannel, "View Channel"],
    [PermissionFlagsBits.SendMessages, "Send Messages"],
    [PermissionFlagsBits.EmbedLinks, "Embed Links"],
    [PermissionFlagsBits.AddReactions, "Add Reactions"],
    [PermissionFlagsBits.ReadMessageHistory, "Read Message History"],
  ]);
  if (missing.length) {
    write("ผิดพลาด", `เตรียมห้องเลือกยศไม่สำเร็จ เพราะใน #${channel.name} ขาดสิทธิ์ ${missing.join(", ")}`);
    return;
  }

  if (!me.permissions.has(PermissionFlagsBits.ManageRoles)) {
    write("เตือน", "บอทไม่มีสิทธิ์ Manage Roles ทั้งเซิร์ฟเวอร์ จึงแจกยศไม่ได้");
  }

  for (const item of config.roles) {
    const role = await channel.guild.roles.fetch(item.roleId).catch(() => null);
    if (!role) {
      write("ผิดพลาด", `ไม่พบยศ ${item.name} ตรวจ roleId ใน config.js`);
      continue;
    }
    if (role.position >= me.roles.highest.position) {
      write("เตือน", `ยศ "${role.name}" สูงกว่าหรือเท่ากับยศบอท กดอิโมจิแล้วจะขึ้น Missing Permissions`);
    }
  }

  roleMessageId = readRoleMessageId();
  const savedId = roleMessageId;
  let message = savedId ? await channel.messages.fetch(savedId).catch(() => null) : null;
  const embed = rolePickEmbed(channel.guild);

  if (message) {
    await message.edit({ embeds: [embed] });
    write("ระบบ", `อัปเดตประกาศเลือกยศเดิมใน #${channel.name} ข้อความ ${message.id}`);
  } else {
    message = await channel.send({ embeds: [embed] });
    write("ระบบ", `ส่งประกาศเลือกยศใหม่ใน #${channel.name} ข้อความ ${message.id}`);
  }

  saveRoleMessageId(message.id);

  for (const item of config.roles) {
    const already = message.reactions.cache.some((reaction) => sameEmoji(reaction.emoji, item.emoji));
    if (already) continue;
    await message.react(String(item.emoji).trim()).catch((error) => {
      write("ผิดพลาด", `ใส่อิโมจิของยศ ${item.name} ไม่สำเร็จ: ${error.message} ต้องอยู่ในเซิร์ฟเวอร์นี้และใส่เป็น <:ชื่อ:ไอดี>`);
    });
  }
}

async function resolveReaction(reaction) {
  if (reaction.partial) await reaction.fetch();
  if (reaction.message.partial) await reaction.message.fetch();
  return reaction;
}

async function onReaction(reaction, user, added) {
  if (user.bot) return;

  try {
    reaction = await resolveReaction(reaction);
  } catch (error) {
    write("ผิดพลาด", `อ่านปฏิกิริยาไม่สำเร็จ: ${error.message}`);
    return;
  }

  const message = reaction.message;
  if (message.channelId !== config.roleChannelId || message.id !== roleMessageId) return;

  const member = await message.guild.members.fetch(user.id).catch(() => null);
  const who = person(user, member);
  const picked = config.roles.find((role) => sameEmoji(reaction.emoji, role.emoji));
  const channelName = message.channel?.name ?? config.roleChannelId;

  if (!picked) {
    write("อิโมจิ", `${who} ${added ? "กด" : "ยกเลิก"} ${emojiLabel(reaction.emoji)} ใน #${channelName} แต่อิโมจิไม่ได้ผูกกับยศ`);
    return;
  }

  write("อิโมจิ", `${who} ${added ? "กด" : "ยกเลิก"} ${emojiLabel(reaction.emoji)} เพื่อ${added ? "รับ" : "ถอด"}ยศ ${picked.name} ใน #${channelName}`);

  if (!member) {
    write("ผิดพลาด", `หาสมาชิก ${who} ในเซิร์ฟเวอร์ไม่เจอ จึงเปลี่ยนยศไม่ได้`);
    return;
  }

  const other = config.roles.find((role) => role.roleId !== picked.roleId);
  const discordRole = message.guild.roles.cache.get(picked.roleId) ?? (await message.guild.roles.fetch(picked.roleId));

  if (!discordRole.editable) {
    write("ผิดพลาด", `เปลี่ยนยศให้ ${who} ไม่ได้ เพราะยศ "${discordRole.name}" สูงกว่ายศบอท หรือบอทไม่มีสิทธิ์ Manage Roles`);
    return;
  }

  if (added) {
    const hadOther = member.roles.cache.has(other.roleId);
    await member.roles.add(picked.roleId);
    if (hadOther) await member.roles.remove(other.roleId);

    const otherReaction = message.reactions.cache.find((item) => sameEmoji(item.emoji, other.emoji));
    if (otherReaction) {
      await otherReaction.users.remove(user.id).catch((error) => {
        write("เตือน", permissionHint(error, `สลับยศให้ ${who} แล้ว แต่ลบอิโมจิ ${other.name} ไม่ได้ เพราะขาดสิทธิ์ Manage Messages`));
      });
    }

    write("ยศ", hadOther ? `${who} ได้รับ ${picked.name} และถูกถอด ${other.name}` : `${who} ได้รับ ${picked.name}`);
    return;
  }

  if (member.roles.cache.has(picked.roleId)) {
    await member.roles.remove(picked.roleId);
    write("ยศ", `${who} ถูกถอด ${picked.name}`);
    return;
  }

  write("ยศ", `${who} ยกเลิกอิโมจิ ${picked.name} แต่มียศนั้นไม่ได้อยู่แล้ว`);
}

checkSetup();

if (!process.env.LOG_WEBHOOK_URL?.trim()) {
  write("เตือน", "ยังไม่ได้ใส่ LOG_WEBHOOK_URL ในไฟล์ .env บันทึกจะอยู่แค่ในโฟลเดอร์ logs", { webhook: false });
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildMessageReactions],
  partials: [Partials.Message, Partials.Channel, Partials.Reaction, Partials.User, Partials.GuildMember],
});

client.once(Events.ClientReady, (readyClient) => {
  const banner = config.bannerUrl || (bannerAttachment() ? config.bannerFile : "ไม่มีรูป");
  const servers = readyClient.guilds.cache.map((guild) => guild.name).join(", ") || "ไม่พบเซิร์ฟเวอร์";
  write("ออนไลน์", `${readyClient.user.tag} พร้อมทำงานใน ${servers} ห้องต้อนรับ ${config.welcomeChannelId} ห้องเลือกยศ ${config.roleChannelId} รูป ${banner}`);
  ensureRolePanel(readyClient).catch((error) => {
    write("ผิดพลาด", `ส่งประกาศเลือกยศไม่สำเร็จ: ${permissionHint(error, "ตรวจสิทธิ์ Send Messages, Embed Links และ Add Reactions ในห้องเลือกยศ")}`);
  });
});

client.on(Events.ShardDisconnect, (event) => {
  write("ออฟไลน์", `การเชื่อมต่อขาด รหัส ${event.code}${event.reason ? ` สาเหตุ ${event.reason}` : ""}`);
});

client.on(Events.ShardReconnecting, () => {
  write("ออนไลน์", "กำลังเชื่อมต่อใหม่");
});

client.on(Events.ShardResume, () => {
  write("ออนไลน์", "เชื่อมต่อกลับแล้ว");
});

client.on(Events.Error, (error) => {
  write("ผิดพลาด", `ข้อผิดพลาดของบอท: ${error.message}`);
});

client.on(Events.GuildMemberAdd, (member) => {
  write("สมาชิก", `${person(member.user, member)} เข้าเซิร์ฟเวอร์ ${member.guild.name}`);
  sendWelcome(member).catch((error) => {
    write("ผิดพลาด", `ส่งการ์ดต้อนรับไม่สำเร็จ: ${permissionHint(error, "ตรวจสิทธิ์ View Channel, Send Messages และ Embed Links ในห้อง welcome")}`);
  });
});

client.on(Events.GuildMemberRemove, (member) => {
  const user = member.user;
  const who = user ? person(user, member) : `รหัส ${member.id}`;
  write("สมาชิก", `${who} ออกจากเซิร์ฟเวอร์ ${member.guild.name}`);
});

client.on(Events.GuildMemberUpdate, (oldMember, newMember) => {
  if (oldMember.pending && !newMember.pending) {
    write("สมาชิก", `${person(newMember.user, newMember)} ผ่านการคัดกรองแล้ว`);
    sendWelcome(newMember).catch((error) => {
      write("ผิดพลาด", `ส่งการ์ดต้อนรับไม่สำเร็จ: ${permissionHint(error, "ตรวจสิทธิ์ View Channel, Send Messages และ Embed Links ในห้อง welcome")}`);
    });
  }
});

client.on(Events.MessageReactionAdd, (reaction, user) => {
  onReaction(reaction, user, true).catch((error) => {
    write("ผิดพลาด", `ให้ยศไม่สำเร็จ: ${permissionHint(error, "ลากยศบอทให้สูงกว่า 2 ยศที่จะแจก และให้บอทมีสิทธิ์ Manage Roles")}`);
  });
});

client.on(Events.MessageReactionRemove, (reaction, user) => {
  onReaction(reaction, user, false).catch((error) => {
    write("ผิดพลาด", `ถอดยศไม่สำเร็จ: ${error.message}`);
  });
});

let stopped = false;
function markOffline(reason) {
  if (stopped) return;
  stopped = true;
  write("ออฟไลน์", reason);
}

async function stopBot(reason) {
  markOffline(reason);
  await flushLogs();
  client.destroy();
  process.exit(0);
}

process.on("SIGINT", () => {
  stopBot("ปิดบอทตามคำสั่ง");
});

process.on("SIGTERM", () => {
  stopBot("ระบบสั่งปิดบอท");
});

client.login(process.env.DISCORD_TOKEN.trim()).catch(async (error) => {
  write("ออฟไลน์", `เข้าสู่ระบบไม่สำเร็จ: ${error.message}`);
  await flushLogs();
  process.exit(1);
});
