import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import config from "../config.js";

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const logsDir = path.join(root, "logs");
const colors = {
  ออนไลน์: 0x3ba55d,
  ออฟไลน์: 0x747f8d,
  อิโมจิ: 0x5865f2,
  ยศ: 0xf0b232,
  ต้อนรับ: 0x00e5ff,
  สมาชิก: 0x2480c5,
  ระบบ: 0x99aab5,
  เตือน: 0xfaa61a,
  ผิดพลาด: 0xed4245,
};

const queue = [];
let timer = null;
let sending = false;
let warnedInvalidWebhook = false;

function stamp() {
  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Bangkok",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(new Date());
  const get = (type) => parts.find((part) => part.type === type)?.value ?? "00";
  const day = `${get("year")}-${get("month")}-${get("day")}`;
  return { day, time: `${day} ${get("hour")}:${get("minute")}:${get("second")}` };
}

function webhookUrl() {
  const url = process.env.LOG_WEBHOOK_URL?.trim() ?? "";
  if (!url) return "";
  const valid = /^https:\/\/((canary|ptb)\.)?discord(app)?\.com\/api\/webhooks\/\d+\/[\w-]+$/;
  if (!valid.test(url)) {
    if (!warnedInvalidWebhook) {
      warnedInvalidWebhook = true;
      write("เตือน", "LOG_WEBHOOK_URL ในไฟล์ .env ไม่ใช่ลิงก์ webhook ของ Discord", { webhook: false });
    }
    return "";
  }
  return url;
}

function scheduleWebhook() {
  if (timer || sending) return;
  timer = setTimeout(() => {
    timer = null;
    flushLogs();
  }, 800);
}

export function write(category, message, options = {}) {
  const { day, time } = stamp();
  const line = `[${time}] [${category}] ${message}`;
  if (category === "ผิดพลาด") console.error(line);
  else console.log(line);

  try {
    fs.mkdirSync(logsDir, { recursive: true });
    fs.appendFileSync(path.join(logsDir, `${day}.log`), `${line}\n`, "utf8");
  } catch (error) {
    console.error(`เขียนไฟล์ log ไม่สำเร็จ: ${error.message}`);
  }

  if (options.webhook === false || !webhookUrl()) return;
  queue.push({ category, message: String(message).slice(0, 4000), time });
  scheduleWebhook();
}

export async function flushLogs() {
  if (timer) {
    clearTimeout(timer);
    timer = null;
  }
  const url = webhookUrl();
  if (!url || sending || queue.length === 0) return;

  sending = true;
  try {
    let retries = 0;
    while (queue.length) {
      const batch = queue.splice(0, 10);
      const response = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username: `${config.serverName || "Bot"} Log`.slice(0, 80),
          embeds: batch.map((item) => ({
            title: item.category,
            description: item.message,
            color: colors[item.category] ?? 0x99aab5,
            footer: { text: item.time },
          })),
        }),
      });

      if (response.status === 429 && retries < 2) {
        const body = await response.json().catch(() => ({}));
        retries += 1;
        queue.unshift(...batch);
        await new Promise((resolve) => setTimeout(resolve, Math.ceil((body.retry_after ?? 1) * 1000)));
        continue;
      }

      if (!response.ok) {
        write("เตือน", `ส่ง log เข้า Discord ไม่สำเร็จ รหัส ${response.status}`, { webhook: false });
        break;
      }
    }
  } catch (error) {
    write("เตือน", `ส่ง log เข้า Discord ไม่สำเร็จ: ${error.message}`, { webhook: false });
  } finally {
    sending = false;
    if (queue.length) scheduleWebhook();
  }
}
