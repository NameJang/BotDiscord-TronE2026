@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is not installed. Install Node.js 18 or newer from https://nodejs.org
  pause
  exit /b 1
)
if not exist node_modules (
  echo Installing packages...
  npm install
  if errorlevel 1 (
    pause
    exit /b 1
  )
)
node src/index.js
echo.
pause
